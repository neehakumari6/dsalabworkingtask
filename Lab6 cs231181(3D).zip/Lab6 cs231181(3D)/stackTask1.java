
public class stackTask1
{
    private int arr[];
    private int size;
    private int index = 0;

    public stackTask1(int size){
        this.size = size;
        arr = new int[size];
    }
    public boolean isFull(){
        if (index == size){
            return true;
        }
        else {
            return false;
        }
    }
    public boolean isEmpty(){
        if(index == 0){
            return true;
        }
        return false;
    }

    public void push(int element){
        if(isFull()){
            System.out.println("Stack is full");
        }
        else{
            arr[index] = element;
            index++;
        }
    }
    public int pop(){
        if(isEmpty()){
            System.out.println("Stack is isEmpty");
        }

        return arr[--index];

    }
    public int Size(){
        return index;
    }
    public static void main(String[] args) {
        stackTask1 s = new stackTask1(5);
        s.push(20);
        s.push(30);
        s.push(40);
        s.push(50);
        s.push(60);
        System.out.println("Size of amn Array After push "+s.Size());
        System.out.println("Pop Element Froim Stack ");
        while(!s.isEmpty()){
            System.out.println(s.pop());

        }
        System.out.println("Size of  Array After pop "+s.Size());
    }
}
