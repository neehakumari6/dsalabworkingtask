public class searchElement {
    static class Node{
        int data;
        Node next;
      public  Node(int data){
            this.data = data;
            this.next = null;
        }

    }
    static class Stack{
        static Node head = null;
        public static void push(int data){
            Node newNode = new Node(data);

            if (head==null){
                head =newNode;
            }
            else {
                newNode.next = head;
                head = newNode;
            }
        }
        public static boolean isEmpty(){
            return head ==null;
        }
        public static int pop(){
            if (isEmpty()){
                System.out.println("Stack is full");
                return -1;
            }
            Node current = head;
            head = head.next;
            return current.data;
        }
        public static int peek(){
            if (isEmpty()){
                System.out.println("Stack is full");
                return -1;
            }
            return head.data;
        }
        public static int searchItem(Stack stack, int element) {
            int index = 0;
            Node current = head;
            while (current != null) {
                if (current.data == element) {
                    return index;
                }
                current = current.next;
                index++;
            }

            return index = -1;
        }
    }
    public static void main(String[] args) {
        Stack stack = new Stack();
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);
        stack.push(60);

        int pos =  stack.searchItem(stack, 40);

        System.out.println(pos);
    }
}
