public class reverseStrig {
    static class Node{
        char data;
        Node next;

       public Node(char data){
            this.data = data;
            this.next = null;
        }
    }
    static class stack{
        public static Node head =  null;
        public void push(char string){
            Node newNode = new Node(string);
            if (head == null){
                head = newNode;
            }
            else {
                newNode.next = head;
                head = newNode;
            }

        }
        public boolean isEmpty(){
            return head == null;
        }
        public char pop(){
            if (isEmpty()){
                System.out.println("empty");
                return 'n';
            }
            Node current = head;
            head = head.next;
            return current.data;
        }
    }
    public static void main(String[] args) {
        stack s = new stack();
        String text = "hello";
        for (char c: text.toCharArray()){
            s.push(c);
        }
        while (!s.isEmpty()){
            System.out.print(s.pop());
        }
    }
}
