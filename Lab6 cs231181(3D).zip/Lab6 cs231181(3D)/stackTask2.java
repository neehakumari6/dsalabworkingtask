public class stackTask2{

    private Node top;
    public static class Node{
        public int data;
        public Node next;
        public Node(int data){
            this.data = data;
            this.next = null;

        }
    }
    public void push(int elemnt) {
        Node newNode = new Node(elemnt);
        newNode.next = top;
        top = newNode;
    }
    public Node pop(){
        Node temp = top;
        top = top.next;
        return temp;
    }
    public void displayList(){
        Node current = top;
        while(current != null){
            System.out.print(current.data+ "-> ");
            current = current.next;
        }
    }
    public static void main (String[] args) {
        stackTask2 s = new stackTask2();
        s.push(20);
        s.push(30);
        s.push(40);
        s.push(50);
        s.push(60);

        s.displayList();
        s.pop();
        System.out.println();
        System.out.println("After Pop");
        s.displayList();
    }
}
