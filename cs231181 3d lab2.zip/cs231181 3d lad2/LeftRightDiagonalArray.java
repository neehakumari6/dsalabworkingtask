import java.util.Scanner;

public class LeftRightDiagonalArray {
    public static void main(String[] args) {
        Scanner r= new Scanner(System.in);

        System.out.println("enter element for left and right diadonal");
        int n = r.nextInt();
        int[][] Array = new int[n][n];
        System.out.println("enter array elements ");
        for (int i = 0; i<n; i++){
            for (int k = 0; k<n; k++){
                Array[i][k] = r.nextInt();
            }
        }
        int LeftDigonalSum = 0;
        for (int j = 0; j<n; j++){
            LeftDigonalSum += Array[j][j];
        }
        System.out.println("sum of left diagonal"+LeftDigonalSum);

        int RightDiagonalSum = 0;
        for (int j = 0; j<n; j++){
            RightDiagonalSum += Array[j][n-j-1];
        }
        System.out.println(" sum of right diagonal is "+RightDiagonalSum);
    }
}
