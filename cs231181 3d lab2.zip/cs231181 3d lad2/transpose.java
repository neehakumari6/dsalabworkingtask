import java.util.Scanner;

public class transpose {
    public static void main(String[] args) {
        int array[][]=new int[2][2];
        Scanner r=new Scanner (System.in);
        System.out.println("enter array data");
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                array[i][j]=r.nextInt();
            }
        }
        System.out.println("Array matrix");
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                System.out.println(array[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println(" Transpose Matrix");
        for(int i=0; i<2; i++){
            for(int j=0; j<2; j++){
                System.out.println(array[j][i] + " ");
            }
            System.out.println();
        }
    }
}
