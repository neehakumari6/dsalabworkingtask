
public class doubleLink {

    Node head;
    Node tail;

    static class Node {
        int data;
        Node previous;
        Node next;

        public Node(int data) {
            this.data = data;
            this.previous = null;
            this.next = null;
        }
    }
    public void insertAtBegining(int newdata) {
        Node newNode = new Node(newdata);

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            head.previous = newNode;
            newNode.next = head;
            head = newNode;
        }
    }

    public void insertAtEnd(int newdata) {
        Node newNode = new Node(newdata);

        if (tail == null)
        {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
        }
    }


    public void deleteAtStart() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        if (head == tail)
        {
            head = null;
            tail = null;
        } else {
            head = head.next;
            head.previous = null;
        }
        System.out.println("deleted from the starting.");
    }

    public void deleteAtEnd() {
        if (tail == null) {
            System.out.println("List is empty.");
            return;
        }
        if (head == tail)
        {
            head = null;
            tail = null;
        } else {
            tail = tail.previous;
            tail.next = null;
        }
        System.out.println("Node deleted from the end.");
    }


    public void displaytList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {

        doubleLink d = new   doubleLink ();


        d.insertAtBegining(30);
        d.insertAtBegining(40);
        d.insertAtBegining(50);


        d.insertAtEnd(60);
        d.insertAtEnd(70);
       d.insertAtEnd(80);

        System.out.println("element present in list:");
        d.displaytList();

        d.deleteAtStart();
        d.deleteAtEnd();

        System.out.println("list of elements after delete from start and end");
        d.displaytList();
    }
}
