

public class doubleLinkkk{

    Node head;
    Node tail;

    static class Node {
        int data;
        Node previous;
        Node next;

        public Node(int data) {
            this.data = data;
            this.previous = null;
            this.next = null;
        }
    }
    public void insertAtEnd(int data) {
        Node newNode = new Node(data);

        if (head == null)
        {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
        }
    }


    public void insertAtPos(int pos, int data) {
        Node newNode = new Node(data);
        if (pos == 1) {
            newNode.next = head;
            if (head != null) {
                head.previous = newNode;
            }
            head = newNode;
            if (tail == null)
            {
                tail = newNode;
            }
            return;
        }

        Node current = head;
        for (int i = 1; i < pos- 1 && current != null; i++) {
            current = current.next;
        }

        if (current == null)
        {
            insertAtEnd(data);
        } else {
            newNode.next = current.next;
            if (current.next != null)
            {
                current.next.previous = newNode;
            }
            current.next = newNode;
            newNode.previous = current;

            if (newNode.next == null)
            {
                tail = newNode;
            }
        }
    }


    public void deleteFromPosition(int pos) {
        if (head == null)
        {
            System.out.println("List is empty.");
            return;
        }

        if (pos == 1)
        {
            head = head.next;
            if (head != null) {
                head.previous = null;
            } else {
                tail = null;
            }
            return;
        }

        Node current = head;
        for (int i = 1; i < pos && current != null; i++) {
            current = current.next;
        }

        if (current == null) {
            System.out.println("Position out of bounds.");
        } else {
            if (current.next != null) {
                current.next.previous = current.previous;
            } else {
                tail = current.previous;
            }
            current.previous.next = current.next;
        }
    }

    public void displayList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

    }

    public static void main(String[] args) {
        doubleLinkkk d = new doubleLinkkk();

        d.insertAtEnd(10);
        d.insertAtEnd(20);
        d.insertAtEnd(30);
        d.insertAtEnd(40);

        System.out.println("after inserting at the end:");
        d.displayList();

        d.insertAtPos(2, 90);
        System.out.println(" after inserting a element at position 2:");
        d.displayList();

        d.deleteFromPosition(3);
        System.out.println(" after delete node position 3:");
        d.displayList();
    }
}

