
public class doubleLinkk{

    Node head;
    Node tail;

    static class Node {
        int data;
        Node prev;
        Node next;

        public Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }
    public void insertBegining(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            head.prev = newNode;
            newNode.next = head;
            head = newNode;
        }
    }

    public void insertEnd(int data) {
        Node newNode = new Node(data);

        if (tail == null)
        {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void displayList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + "  ");
            current = current.next;
        }
        // Ending at null
        System.out.println("null");
    }

    public void printListBackward() {
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + "  ");
            current = current.prev;
        }

    }

    public static void main(String[] args) {

        doubleLinkk d = new doubleLinkk();

        d.insertBegining(20);
        d.insertBegining(30);
        d.insertBegining(40);

        d.insertEnd(50);
        d.insertEnd(60);

        System.out.println("Forward:");
        d.displayList();

        System.out.println("Backward:");
        d.printListBackward();
    }
}

