import java.util.LinkedList;
import java.util.Queue;

public class getminimum {
    static class queue{
        Queue<Integer> q = new LinkedList<>();
        Queue<Integer> queue = new LinkedList<>();

        public void  add(int element){
            queue.add(element);
            while (!queue.isEmpty() && queue.peek()>element){
                queue.poll();
            }
            queue.add(element);
        }
        public int getMinimum(){
            return queue.peek();
        }

    }
    public static void main(String[] args) {
        queue q = new queue();
        q.add(20);
        q.add(30);
        q.add(40);
        q.add(10);
        q.add(60);

        System.out.println(q.getMinimum());


    }
}
