import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class reverseQueue {

    public static Queue<Integer> reverseElement(Queue<Integer> queue, int q){
        if (queue == null || q>queue.size() || q<=0){
            return queue;
        }
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i<q; i++){
            stack.push(queue.poll());
        }
        while (!stack.isEmpty()){
            queue.add(stack.pop());
        }
        for (int i = 0; i<queue.size()-q; i++){
            queue.add(queue.poll());
        }
        return queue;
    }
    public static void main(String[] args) {
        Queue<Integer> queueee = new LinkedList<>();

        queueee.add(10);
        queueee.add(30);
        queueee.add(40);
        queueee.add(70);
        queueee.add(80);

        System.out.println(queueee);

        int q = queueee.size();
        queueee = reverseElement(queueee, q);
        System.out.println("Revere element  "+queueee);

    }
}
